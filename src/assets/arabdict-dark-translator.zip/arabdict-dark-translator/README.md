# Arabdict Dark Translator

A Manifest V3 extension for Chrome and Brave that translates selected German text into Arabic in a dark floating popup.

## Install

1. Extract the ZIP file.
2. Open `chrome://extensions` in Chrome, `brave://extensions` in Brave, or `edge://extensions` in Microsoft Edge.
3. Enable **Developer mode**.
4. Click **Load unpacked** and choose the `arabdict-dark-translator` folder.
5. Select German text on a webpage and click the Deutsch mit Rinkute logo.

## PDF documents

Chrome, Brave, and Edge protect their built-in PDF pages, so extensions cannot place a floating icon inside those viewers. Version 1.6 includes its own dark PDF viewer where the floating Rinkute logo works normally:

1. Open the extension from the browser toolbar.
2. Click **Open translator PDF viewer**.
3. If the PDF is already open online, the extension tries to load it automatically. Otherwise click **Open PDF** and choose the file from your device.
4. Select German text and click the floating logo beside it.

The viewer includes selectable text, page controls, zoom, fit-to-page, a custom scrollbar, and the same Arabdict translation popup used on websites. On scanned/image-only pages, **Quick select** starts automatically: drag a box over the German sentence or paragraph you need, wait briefly for the local OCR, then click the floating Rinkute logo. This reads only the selected area and is much faster than processing a whole page. Use **OCR full page** only when you need every word on the page to become selectable. OCR stays on the device.

The extension looks up dictionary entries and examples on Arabdict. When Arabdict has no dictionary result, an optional MyMemory sentence-translation fallback can be enabled or disabled in Options.

Version 1.3 adds the Deutsch mit Rinkute logo, centers the loading state, and closes the translation popup when the user clicks outside it.

Version 1.4 adds a dedicated PDF translation window and Microsoft Edge packaging compatibility.

Version 1.5 adds the “By Rinkute” signature to the translation footer.

Version 1.6 adds the custom Rinkute PDF viewer, including direct floating-logo translation in PDF text. The viewer uses Mozilla PDF.js under its included Apache 2.0 license.

Version 1.7 enables XFA/form document rendering and adds offline German OCR for scanned PDF pages. The OCR engine uses Tesseract.js under its included Apache 2.0 license.

Version 1.8 opens PDFs fitted to the full window, makes PDF/XFA text layers explicitly selectable, and automatically runs OCR when the current page has no usable text layer.

Version 1.9 places the floating logo at the exact point where the mouse selection ends and plays multi-sentence Arabdict pronunciation continuously, one natural sentence chunk after another.

Version 1.10 accelerates scanned-page recognition with background OCR warm-up, an adaptive lower-resolution render, lighter TSV word extraction, and no unnecessary OCR pass for selectable XFA documents.

Version 1.11 replaces automatic full-page recognition with fast region OCR. Scanned pages immediately enter Quick select mode, where drawing around one sentence or paragraph recognizes only that crop and opens the normal floating-logo workflow. Full-page OCR remains available as an optional slower action.

Version 1.12 uses smaller, more balanced typography throughout the translation popup. The main Arabic translation is now only slightly larger than Arabic examples, while German text, dictionary entries, labels, and action buttons are also more compact.

## Notes

- Browser-internal pages and extension-store pages do not allow content scripts.
- The extension caches successful lookups locally for seven days.
- Website markup can change over time; if Arabdict redesigns its result pages, the parser may need an update.
