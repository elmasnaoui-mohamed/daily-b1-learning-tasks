importScripts("translator.js");

const DEFAULTS = {
  showSelectionIcon: true,
  showExamples: true,
  fallbackTranslation: true,
  maxExamples: 3
};

chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({
    id: "arabdict-translate",
    title: "Translate to Arabic with Arabdict",
    contexts: ["selection"]
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "arabdict-translate" || !tab?.id || !info.selectionText) return;
  try {
    await chrome.tabs.sendMessage(tab.id, {
      type: "arabdict-context-lookup",
      text: info.selectionText
    });
  } catch (_) {
    const url = chrome.runtime.getURL(`popup.html?q=${encodeURIComponent(info.selectionText)}&mode=pdf`);
    await chrome.windows.create({
      url,
      type: "popup",
      width: 460,
      height: 700,
      focused: true
    });
  }
});

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type === "arabdict-lookup") {
    lookup(message.text).then(sendResponse).catch((error) => {
      sendResponse({ ok: false, error: error.message || "Translation failed." });
    });
    return true;
  }
  if (message?.type === "arabdict-options") {
    chrome.runtime.openOptionsPage();
  }
});

async function getSettings() {
  return { ...DEFAULTS, ...(await chrome.storage.sync.get(DEFAULTS)) };
}

async function lookup(rawText) {
  const text = String(rawText || "").replace(/\s+/g, " ").trim().slice(0, 1500);
  if (!text) throw new Error("Select some German text first.");

  const settings = await getSettings();
  const cacheKey = `lookup:v5:${settings.showExamples}:${settings.maxExamples}:${settings.fallbackTranslation}:${text.toLocaleLowerCase("de-DE")}`;
  const cached = await chrome.storage.local.get(cacheKey);
  if (cached[cacheKey] && Date.now() - cached[cacheKey].savedAt < 7 * 86400000) {
    return cached[cacheKey].value;
  }

  const url = `https://www.arabdict.com/de/deutsch-arabisch/${encodeURIComponent(text).replace(/%20/g, "+")}`;
  let parsed = { entries: [], exact: null, isExact: false };
  let arabdictError = "";
  try {
    const response = await fetch(url, { headers: { Accept: "text/html" }, credentials: "omit" });
    if (!response.ok) throw new Error(`Arabdict returned ${response.status}.`);
    parsed = ArabdictParser.parseSearchPage(await response.text(), text);
  } catch (error) {
    arabdictError = error?.message || "Arabdict is temporarily unavailable.";
  }
  const isSingleWord = text.split(/\s+/).length === 1;
  const useDictionary = parsed.entries.length > 0 && (parsed.isExact || isSingleWord);

  let examples = [];
  if (settings.showExamples && useDictionary) {
    const candidates = parsed.entries.filter((entry) => entry.id).slice(0, 5);
    const exampleSets = await Promise.all(candidates.map(async (entry) => {
      try {
        const detailsUrl = `https://www.arabdict.com/de/de-ar/details?la=la&ids=${entry.id}&term=${encodeURIComponent(text)}`;
        const detailsResponse = await fetch(detailsUrl, { headers: { Accept: "text/html" }, credentials: "omit" });
        if (!detailsResponse.ok) return [];
        return ArabdictParser.parseExamplesPage(await detailsResponse.text());
      } catch (_) {
        return [];
      }
    }));
    examples = (exampleSets.find((set) => set.length) || []).slice(0, settings.maxExamples);
  }

  let fallback = "";
  let fallbackSource = "";
  if (!useDictionary && settings.fallbackTranslation) {
    fallback = await translateTextWithArabdict(text);
    if (fallback) fallbackSource = "Arabdict text translation";
  }
  if (!useDictionary && !fallback && settings.fallbackTranslation) {
    try {
      const fallbackUrl = `https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=de|ar`;
      const fallbackResponse = await fetch(fallbackUrl, { credentials: "omit" });
      if (fallbackResponse.ok) {
        const data = await fallbackResponse.json();
        fallback = String(data?.responseData?.translatedText || "").trim();
        if (fallback) fallbackSource = "MyMemory fallback";
      }
    } catch (_) {}
  }

  if (!parsed.entries.length && !fallback) {
    throw new Error(arabdictError || "No translation was found. Open Arabdict for a full search.");
  }

  const translation = fallback || parsed.exact?.arabic;
  const [germanAudioTracks, arabicAudioTracks] = await Promise.all([
    getArabdictAudioTracks(text, "de"),
    getArabdictAudioTracks(translation, "ar")
  ]);
  const germanAudioUrl = germanAudioTracks.find((track) => track.url)?.url || "";
  const arabicAudioUrl = arabicAudioTracks.find((track) => track.url)?.url || "";

  const value = {
    ok: true,
    query: text,
    translation,
    entries: fallback ? [] : parsed.entries.slice(0, 5),
    examples,
    source: fallback ? fallbackSource : "Arabdict",
    germanAudioUrl,
    arabicAudioUrl,
    germanAudioTracks,
    arabicAudioTracks,
    sourceUrl: url
  };
  await chrome.storage.local.set({ [cacheKey]: { savedAt: Date.now(), value } });
  return value;
}

async function getArabdictAudioTracks(text, language) {
  const chunks = splitSpeechChunks(text);
  return Promise.all(chunks.map(async (chunk) => ({
    text: chunk,
    url: await getArabdictAudioUrl(chunk, language)
  })));
}

function splitSpeechChunks(value, maximumLength = 180) {
  const text = String(value || "").replace(/\s+/g, " ").trim();
  if (!text) return [];
  const sentences = text.match(/[^.!?…。！？]+(?:[.!?…。！？]+|$)/g) || [text];
  const chunks = [];
  for (const sentenceValue of sentences) {
    let sentence = sentenceValue.trim();
    while (sentence.length > maximumLength && chunks.length < 11) {
      let splitAt = sentence.lastIndexOf(" ", maximumLength);
      if (splitAt < Math.floor(maximumLength * 0.55)) splitAt = maximumLength;
      chunks.push(sentence.slice(0, splitAt).trim());
      sentence = sentence.slice(splitAt).trim();
    }
    if (sentence) chunks.push(sentence);
    if (chunks.length >= 12) break;
  }
  return chunks;
}

async function translateTextWithArabdict(text) {
  const cleaned = String(text || "").replace(/[.!?؟]+$/g, "").trim();
  if (!cleaned) return "";
  try {
    const endpoint = `https://www.arabdict.com/de/de-ar/stranslate?v=2&langone=de&langtwo=ar&dl=&textone=${encodeURIComponent(cleaned)}`;
    const response = await fetch(endpoint, {
      headers: {
        Accept: "text/html",
        "X-Requested-With": "XMLHttpRequest",
        refLang: "de-en"
      },
      credentials: "omit"
    });
    if (!response.ok) return "";
    const body = (await response.text()).trim();
    return body.split("|")[0].trim();
  } catch (_) {
    return "";
  }
}

async function getArabdictAudioUrl(text, language) {
  if (!text) return "";
  try {
    const endpoint = `https://www.arabdict.com/getsound?t=${encodeURIComponent(text)}&lg=${encodeURIComponent(language)}`;
    const response = await fetch(endpoint, { headers: { Accept: "text/html" }, credentials: "omit" });
    if (!response.ok) return "";
    const html = await response.text();
    const source = (html.match(/<(?:audio|source)[^>]+src=["']([^"']+)["']/i) || [])[1];
    return source ? new URL(source, "https://www.arabdict.com/").href : "";
  } catch (_) {
    return "";
  }
}
