import * as pdfjsLib from "./vendor/pdf.min.mjs";
import { EventBus, PDFLinkService, PDFViewer } from "./vendor/pdf_viewer.mjs";

pdfjsLib.GlobalWorkerOptions.workerSrc = "./vendor/pdf.worker.min.mjs";

const container = document.querySelector("#viewerContainer");
const viewerElement = document.querySelector("#viewer");
const emptyState = document.querySelector("#emptyState");
const fileInput = document.querySelector("#fileInput");
const pageNumber = document.querySelector("#pageNumber");
const pageCount = document.querySelector("#pageCount");
const documentName = document.querySelector("#documentName");
const loading = document.querySelector("#loading");
const loadingDetail = document.querySelector("#loadingDetail");
const errorBox = document.querySelector("#errorBox");
const errorText = document.querySelector("#errorText");
const quickSelectButton = document.querySelector("#quickSelect");
const ocrButton = document.querySelector("#ocrPage");
const ocrStatus = document.querySelector("#ocrStatus");
const ocrStatusTitle = document.querySelector("#ocrStatusTitle");
const ocrStatusDetail = document.querySelector("#ocrStatusDetail");

const eventBus = new EventBus();
const linkService = new PDFLinkService({ eventBus });
const pdfViewer = new PDFViewer({
  container,
  viewer: viewerElement,
  eventBus,
  linkService,
  textLayerMode: 1,
  annotationMode: pdfjsLib.AnnotationMode.ENABLE_FORMS
});
linkService.setViewer(pdfViewer);

let currentDocument = null;
let currentTask = null;
let ocrWorkerPromise = null;
const ocrPages = new Set();

const chooseFile = () => fileInput.click();
document.querySelector("#openFile").addEventListener("click", chooseFile);
document.querySelector("#emptyOpenFile").addEventListener("click", chooseFile);
document.querySelector("#errorOpenFile").addEventListener("click", chooseFile);
document.querySelector("#dismissError").addEventListener("click", () => errorBox.classList.add("hidden"));
document.querySelector("#dismissOcrStatus").addEventListener("click", () => ocrStatus.classList.add("hidden"));
quickSelectButton.addEventListener("click", () => toggleQuickSelection(pdfViewer.currentPageNumber));
ocrButton.addEventListener("click", recognizeCurrentPage);

fileInput.addEventListener("change", async () => {
  const file = fileInput.files?.[0];
  if (!file) return;
  await openPdf({ data: new Uint8Array(await file.arrayBuffer()) }, file.name);
  fileInput.value = "";
});

document.querySelector("#previousPage").addEventListener("click", () => {
  if (currentDocument && pdfViewer.currentPageNumber > 1) pdfViewer.currentPageNumber -= 1;
});
document.querySelector("#nextPage").addEventListener("click", () => {
  if (currentDocument && pdfViewer.currentPageNumber < currentDocument.numPages) pdfViewer.currentPageNumber += 1;
});
document.querySelector("#zoomOut").addEventListener("click", () => {
  if (currentDocument) pdfViewer.decreaseScale({ drawingDelay: 250 });
});
document.querySelector("#zoomIn").addEventListener("click", () => {
  if (currentDocument) pdfViewer.increaseScale({ drawingDelay: 250 });
});
document.querySelector("#fitWidth").addEventListener("click", () => {
  if (currentDocument) pdfViewer.currentScaleValue = "page-fit";
});
pageNumber.addEventListener("change", () => {
  const value = Math.max(1, Math.min(currentDocument?.numPages || 1, Number(pageNumber.value) || 1));
  if (currentDocument) pdfViewer.currentPageNumber = value;
});

eventBus.on("pagesinit", () => {
  pdfViewer.currentScaleValue = "page-fit";
  loading.classList.add("hidden");
  container.focus({ preventScroll: true });
  inspectPageText(1);
});
eventBus.on("pagechanging", ({ pageNumber: number }) => {
  pageNumber.value = number;
  updateButtons();
  inspectPageText(number);
  syncQuickSelectButton(number);
});
eventBus.on("scalechanging", ({ scale }) => {
  document.querySelector("#fitWidth").textContent = `${Math.round(scale * 100)}%`;
});

window.addEventListener("keydown", (event) => {
  if (!currentDocument || /^(INPUT|TEXTAREA)$/.test(event.target.tagName)) return;
  if (event.key === "PageDown" || event.key === "ArrowRight") pdfViewer.nextPage();
  if (event.key === "PageUp" || event.key === "ArrowLeft") pdfViewer.previousPage();
  if ((event.ctrlKey || event.metaKey) && (event.key === "+" || event.key === "=")) {
    event.preventDefault();
    pdfViewer.increaseScale({ drawingDelay: 250 });
  }
  if ((event.ctrlKey || event.metaKey) && event.key === "-") {
    event.preventDefault();
    pdfViewer.decreaseScale({ drawingDelay: 250 });
  }
});

async function openPdf(source, name) {
  errorBox.classList.add("hidden");
  loading.classList.remove("hidden");
  loadingDetail.textContent = name || "Preparing the document";
  try {
    if (currentTask) await currentTask.destroy();
    currentTask = null;
    currentDocument = null;
    pdfViewer.setDocument(null);
    linkService.setDocument(null);
    currentTask = pdfjsLib.getDocument({
      ...source,
      enableXfa: true,
      useSystemFonts: true,
      fontExtraProperties: true,
      cMapUrl: "./vendor/cmaps/",
      cMapPacked: true,
      standardFontDataUrl: "./vendor/standard_fonts/",
      wasmUrl: "./vendor/wasm/"
    });
    currentTask.onProgress = ({ loaded, total }) => {
      if (total) loadingDetail.textContent = `Loading ${Math.round(loaded / total * 100)}%`;
    };
    currentDocument = await currentTask.promise;
    pdfViewer.setDocument(currentDocument);
    linkService.setDocument(currentDocument);
    pageCount.textContent = currentDocument.numPages;
    documentName.textContent = name || "PDF document";
    document.title = `${name || "PDF"} · Rinkute Translator`;
    emptyState.classList.add("hidden");
    ocrPages.clear();
    quickSelectButton.classList.remove("active", "recommended");
    ocrButton.classList.remove("recommended");
    updateButtons();
  } catch (error) {
    currentTask = null;
    currentDocument = null;
    loading.classList.add("hidden");
    emptyState.classList.remove("hidden");
    showError(error);
  }
}

async function inspectPageText(number) {
  if (!currentDocument || ocrPages.has(number)) return;
  try {
    const page = await currentDocument.getPage(number);
    const content = await page.getTextContent();
    const characterCount = content.items.reduce((sum, item) => sum + String(item.str || "").trim().length, 0);
    const needsOcr = characterCount < 20 && !currentDocument.isPureXfa;
    quickSelectButton.classList.toggle("recommended", needsOcr);
    ocrButton.classList.remove("recommended");
    ocrButton.title = characterCount < 20
      ? "Recognize the whole page (slower)"
      : "Recognize German text on the current page";
    if (needsOcr && number === pdfViewer.currentPageNumber) {
      enableQuickSelection(number, true);
    }
  } catch (_) {}
}

function toggleQuickSelection(number) {
  if (!currentDocument || !number) return;
  const pageView = pdfViewer.getPageView(number - 1);
  const existing = pageView?.div?.querySelector(".quick-ocr-layer");
  if (existing) {
    existing.remove();
    syncQuickSelectButton(number);
    ocrStatus.classList.add("hidden");
    return;
  }
  enableQuickSelection(number, true);
}

function enableQuickSelection(number, announce = false, attempt = 0) {
  if (!currentDocument || ocrPages.has(number)) return;
  const pageView = pdfViewer.getPageView(number - 1);
  if (!pageView?.div || !pageView.div.clientWidth) {
    if (attempt < 12) setTimeout(() => enableQuickSelection(number, announce, attempt + 1), 100);
    return;
  }
  let layer = pageView.div.querySelector(".quick-ocr-layer");
  if (!layer) {
    layer = document.createElement("div");
    layer.className = "quick-ocr-layer";
    layer.setAttribute("aria-label", "Drag over German text for quick recognition");
    pageView.div.appendChild(layer);
    bindQuickSelection(layer, number);
  }
  syncQuickSelectButton(number);
  if (announce) {
    showOcrStatus("Quick selection ready", "Drag a box over only the German sentence or paragraph you need.", true);
  }
}

function syncQuickSelectButton(number = pdfViewer.currentPageNumber) {
  const pageView = number ? pdfViewer.getPageView(number - 1) : null;
  quickSelectButton.classList.toggle("active", Boolean(pageView?.div?.querySelector(".quick-ocr-layer")));
}

function bindQuickSelection(layer, number) {
  let start = null;
  let rectangle = null;

  const pointInLayer = (event) => {
    const bounds = layer.getBoundingClientRect();
    return {
      x: Math.max(0, Math.min(bounds.width, event.clientX - bounds.left)),
      y: Math.max(0, Math.min(bounds.height, event.clientY - bounds.top))
    };
  };

  const draw = (point) => {
    const left = Math.min(start.x, point.x);
    const top = Math.min(start.y, point.y);
    const width = Math.abs(point.x - start.x);
    const height = Math.abs(point.y - start.y);
    Object.assign(rectangle.style, {
      left: `${left}px`, top: `${top}px`, width: `${width}px`, height: `${height}px`
    });
    return { left, top, width, height };
  };

  layer.addEventListener("pointerdown", (event) => {
    if (event.button !== 0 || layer.dataset.busy === "true") return;
    event.preventDefault();
    window.getSelection()?.removeAllRanges();
    layer.querySelector(".quick-ocr-result")?.remove();
    start = pointInLayer(event);
    rectangle = document.createElement("div");
    rectangle.className = "quick-ocr-rect";
    layer.appendChild(rectangle);
    layer.classList.add("selecting");
    draw(start);
    try { layer.setPointerCapture(event.pointerId); } catch (_) {}
  });

  layer.addEventListener("pointermove", (event) => {
    if (!start || !rectangle) return;
    event.preventDefault();
    draw(pointInLayer(event));
  });

  const finish = (event) => {
    if (!start || !rectangle) return;
    event.preventDefault();
    const region = draw(pointInLayer(event));
    start = null;
    layer.classList.remove("selecting");
    try { layer.releasePointerCapture(event.pointerId); } catch (_) {}
    if (region.width < 8 || region.height < 8) {
      rectangle.remove();
      rectangle = null;
      return;
    }
    const selectionRectangle = rectangle;
    rectangle = null;
    recognizeRegion(number, region, layer, selectionRectangle, { x: event.clientX, y: event.clientY });
  };
  layer.addEventListener("pointerup", finish);
  layer.addEventListener("pointercancel", finish);
}

async function recognizeRegion(number, region, layer, selectionRectangle, pointer) {
  if (layer.dataset.busy === "true") return;
  layer.dataset.busy = "true";
  showOcrStatus("Reading selected text…", "Fast German OCR is working on only this area.", false);
  try {
    const pdfPage = await currentDocument.getPage(number);
    const natural = pdfPage.getViewport({ scale: 1 });
    const naturalWidth = region.width / layer.clientWidth * natural.width;
    const naturalHeight = region.height / layer.clientHeight * natural.height;
    const scale = Math.max(1.8, Math.min(3, Math.sqrt(950000 / Math.max(1, naturalWidth * naturalHeight))));
    const viewport = pdfPage.getViewport({ scale });
    const sourceLeft = region.left / layer.clientWidth * viewport.width;
    const sourceTop = region.top / layer.clientHeight * viewport.height;
    const sourceWidth = Math.max(1, region.width / layer.clientWidth * viewport.width);
    const sourceHeight = Math.max(1, region.height / layer.clientHeight * viewport.height);
    const canvas = document.createElement("canvas");
    canvas.width = Math.ceil(sourceWidth);
    canvas.height = Math.ceil(sourceHeight);
    const context = canvas.getContext("2d", { alpha: false, willReadFrequently: true });
    context.fillStyle = "#fff";
    context.fillRect(0, 0, canvas.width, canvas.height);
    await pdfPage.render({
      canvas,
      canvasContext: context,
      viewport,
      transform: [1, 0, 0, 1, -sourceLeft, -sourceTop],
      intent: "display"
    }).promise;

    const worker = await getOcrWorker();
    const pageSegmentation = canvas.width > canvas.height * 5 ? "7" : "6";
    const result = await worker.recognize(
      canvas,
      { tessedit_pageseg_mode: pageSegmentation, preserve_interword_spaces: "1" },
      { text: true }
    );
    const text = String(result.data.text || "").replace(/\s+/g, " ").trim();
    if (!text) throw new Error("No German text was found. Draw a tighter box around the text and try again.");

    selectionRectangle.remove();
    layer.querySelector(".quick-ocr-result")?.remove();
    const resultSpan = document.createElement("span");
    resultSpan.className = "quick-ocr-result";
    resultSpan.textContent = text;
    Object.assign(resultSpan.style, {
      left: `${region.left}px`, top: `${region.top}px`, width: `${region.width}px`, height: `${region.height}px`,
      fontSize: `${Math.max(8, Math.min(30, region.height * 0.72))}px`
    });
    layer.appendChild(resultSpan);

    const range = document.createRange();
    range.selectNodeContents(resultSpan);
    const selection = window.getSelection();
    selection.removeAllRanges();
    selection.addRange(range);
    showOcrStatus("Text ready", `${text.split(/\s+/).length} words recognized. Click the floating Rinkute logo.`, true);
    requestAnimationFrame(() => {
      document.dispatchEvent(new MouseEvent("mouseup", {
        bubbles: true, cancelable: true, clientX: pointer.x, clientY: pointer.y
      }));
    });
  } catch (error) {
    selectionRectangle.remove();
    showOcrStatus("Could not read this area", error?.message || "Draw a box around the text and try again.", true);
  } finally {
    layer.dataset.busy = "false";
  }
}

async function recognizeCurrentPage() {
  if (!currentDocument || ocrButton.disabled) return;
  const number = pdfViewer.currentPageNumber;
  if (ocrPages.has(number)) {
    showOcrStatus("OCR already added", `Page ${number} is ready for text selection.`, true);
    return;
  }
  ocrButton.disabled = true;
  showOcrStatus("Recognizing German text…", `Preparing page ${number}`, false);
  try {
    const pdfPage = await currentDocument.getPage(number);
    const naturalViewport = pdfPage.getViewport({ scale: 1 });
    const basePixels = naturalViewport.width * naturalViewport.height;
    const scale = Math.max(0.75, Math.min(
      1.45,
      1450 / Math.max(naturalViewport.width, naturalViewport.height),
      Math.sqrt(1500000 / Math.max(1, basePixels))
    ));
    const viewport = pdfPage.getViewport({ scale });
    const canvas = document.createElement("canvas");
    canvas.width = Math.ceil(viewport.width);
    canvas.height = Math.ceil(viewport.height);
    const context = canvas.getContext("2d", { alpha: false, willReadFrequently: true });
    await pdfPage.render({ canvas, canvasContext: context, viewport, intent: "display" }).promise;

    const worker = await getOcrWorker();
    const result = await worker.recognize(
      canvas,
      { tessedit_pageseg_mode: "3", preserve_interword_spaces: "1" },
      { tsv: true, text: true }
    );
    const words = extractOcrWords(result.data.tsv, result.data.blocks);
    if (!words.length) throw new Error("No German text was recognized on this page.");
    addOcrTextLayer(number, words, canvas.width, canvas.height);
    ocrPages.add(number);
    ocrButton.classList.remove("recommended");
    quickSelectButton.classList.remove("active", "recommended");
    showOcrStatus("OCR complete", `${words.length} words on page ${number} are now selectable.`, true);
  } catch (error) {
    showOcrStatus("OCR could not finish", error?.message || "Please try this page again.", true);
  } finally {
    ocrButton.disabled = false;
  }
}

function getOcrWorker() {
  if (!ocrWorkerPromise) {
    ocrWorkerPromise = globalThis.Tesseract.createWorker("deu", 1, {
      workerPath: chrome.runtime.getURL("viewer/vendor/tesseract/worker.min.js"),
      corePath: chrome.runtime.getURL("viewer/vendor/tesseract/core/tesseract-core-lstm.wasm.js"),
      langPath: chrome.runtime.getURL("viewer/vendor/tesseract/lang"),
      workerBlobURL: false,
      gzip: true,
      logger(message) {
        if (message.status) {
          const progress = Number.isFinite(message.progress) ? ` ${Math.round(message.progress * 100)}%` : "";
          ocrStatusDetail.textContent = `${message.status}${progress}`;
        }
      }
    }).catch(error => {
      ocrWorkerPromise = null;
      throw error;
    });
  }
  return ocrWorkerPromise;
}

function extractOcrWords(tsv, blocks) {
  if (tsv) {
    const words = [];
    const rows = String(tsv).split(/\r?\n/);
    for (let index = 1; index < rows.length; index += 1) {
      const columns = rows[index].split("\t");
      if (columns.length < 12 || columns[0] !== "5") continue;
      const text = columns.slice(11).join("\t").trim();
      const left = Number(columns[6]);
      const top = Number(columns[7]);
      const width = Number(columns[8]);
      const height = Number(columns[9]);
      if (text && width > 0 && height > 0) {
        words.push({ text, bbox: { x0: left, y0: top, x1: left + width, y1: top + height } });
      }
    }
    if (words.length) return words;
  }
  const words = [];
  for (const block of blocks || []) {
    for (const paragraph of block.paragraphs || []) {
      for (const line of paragraph.lines || []) {
        for (const word of line.words || []) {
          const text = String(word.text || "").trim();
          if (text && word.bbox) words.push({ text, bbox: word.bbox });
        }
      }
    }
  }
  return words;
}

function addOcrTextLayer(pageNumberValue, words, sourceWidth, sourceHeight) {
  const pageView = pdfViewer.getPageView(pageNumberValue - 1);
  if (!pageView?.div) throw new Error("The page is not ready. Scroll to it and try OCR again.");
  pageView.div.querySelector(".quick-ocr-layer")?.remove();
  pageView.div.querySelector(".ocr-text-layer")?.remove();
  const layer = document.createElement("div");
  layer.className = "ocr-text-layer";
  layer.setAttribute("aria-label", `OCR text for page ${pageNumberValue}`);
  for (const word of words) {
    const { x0, y0, x1, y1 } = word.bbox;
    const span = document.createElement("span");
    span.textContent = `${word.text} `;
    span.style.left = `${x0 / sourceWidth * 100}%`;
    span.style.top = `${y0 / sourceHeight * 100}%`;
    span.style.width = `${Math.max(1, x1 - x0) / sourceWidth * 100}%`;
    span.style.height = `${Math.max(1, y1 - y0) / sourceHeight * 100}%`;
    span.style.fontSize = `${Math.max(7, (y1 - y0) / sourceHeight * pageView.div.clientHeight)}px`;
    layer.appendChild(span);
  }
  pageView.div.appendChild(layer);
}

function showOcrStatus(title, detail, done) {
  ocrStatusTitle.textContent = title;
  ocrStatusDetail.textContent = detail;
  ocrStatus.classList.toggle("done", done);
  ocrStatus.classList.remove("hidden");
}

function showError(error) {
  const message = String(error?.message || error || "The PDF could not be loaded.");
  errorText.textContent = `${message} You can still use the Open PDF button.`;
  errorBox.classList.remove("hidden");
}

function updateButtons() {
  const number = pdfViewer.currentPageNumber || 1;
  document.querySelector("#previousPage").disabled = !currentDocument || number <= 1;
  document.querySelector("#nextPage").disabled = !currentDocument || number >= (currentDocument?.numPages || 1);
}

function nameFromUrl(value) {
  try {
    const url = new URL(value);
    const lastPart = decodeURIComponent(url.pathname.split("/").filter(Boolean).pop() || "PDF document");
    return lastPart.toLowerCase().endsWith(".pdf") ? lastPart : "PDF document";
  } catch (_) {
    return "PDF document";
  }
}

updateButtons();
const warmUpOcr = () => getOcrWorker().catch(() => {});
if ("requestIdleCallback" in window) {
  requestIdleCallback(warmUpOcr, { timeout: 500 });
} else {
  setTimeout(warmUpOcr, 100);
}
const initialUrl = new URLSearchParams(location.search).get("file");
if (initialUrl && /^(https?:|file:)/i.test(initialUrl)) {
  openPdf({ url: initialUrl, withCredentials: true }, nameFromUrl(initialUrl));
}
