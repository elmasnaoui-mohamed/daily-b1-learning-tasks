const form = document.querySelector("#translateForm");
const queryInput = document.querySelector("#query");
const resultBox = document.querySelector("#result");
const params = new URLSearchParams(location.search);
let activeAudio = null;
let audioRunId = 0;

document.querySelector("#options").addEventListener("click", () => chrome.runtime.openOptionsPage());
document.querySelector("#openPdfViewer").addEventListener("click", openPdfViewer);
form.addEventListener("submit", (event) => {
  event.preventDefault();
  translate(queryInput.value);
});

const initialQuery = params.get("q");
if (params.get("mode") === "pdf") document.querySelector("#modeLabel").textContent = "PDF selection";
if (initialQuery) {
  queryInput.value = initialQuery;
  translate(initialQuery);
}

async function translate(rawText) {
  const text = String(rawText || "").replace(/\s+/g, " ").trim();
  if (!text) return;
  resultBox.innerHTML = `<div class="loading"><div><div class="spinner"></div>Looking up translation…</div></div>`;
  try {
    const data = await chrome.runtime.sendMessage({ type: "arabdict-lookup", text });
    if (!data?.ok) throw new Error(data?.error || "Translation failed.");
    render(data);
  } catch (error) {
    resultBox.innerHTML = `<div class="error"><b>Could not translate</b><br>${escapeHtml(error.message)}</div>`;
  }
}

function render(data) {
  const entries = data.entries.length > 1
    ? `<section class="section"><div class="section-title">More meanings</div><div class="entries">${data.entries.slice(0,5).map((item) => `<div class="entry"><div>${escapeHtml(item.german)}</div><div class="ar" lang="ar">${escapeHtml(item.arabic)}</div></div>`).join("")}</div></section>`
    : "";
  const examples = data.examples.length
    ? `<section class="section"><div class="section-title">Examples in context</div><div class="examples">${data.examples.map((item) => `<div class="example"><div class="de">${escapeHtml(item.german)}</div><div class="ar" lang="ar">${escapeHtml(item.arabic)}</div></div>`).join("")}</div></section>`
    : "";
  resultBox.innerHTML = `<div class="source">${escapeHtml(data.query)}</div><div class="translation" lang="ar">${escapeHtml(data.translation)}</div><div class="actions"><button class="action speak-de" type="button">🔊 German</button><button class="action speak-ar" type="button">🔊 Arabic</button><button class="action copy" type="button">Copy</button><a class="action open" href="${escapeHtml(data.sourceUrl)}" target="_blank" rel="noopener">Open Arabdict ↗</a></div>${entries}${examples}<div class="credit"><span>Results: ${escapeHtml(data.source)}</span><span class="byline">By Rinkute</span></div>`;
  resultBox.querySelector(".speak-de").addEventListener("click", () => playAudio(data.germanAudioTracks, data.germanAudioUrl, data.query, "de-DE"));
  resultBox.querySelector(".speak-ar").addEventListener("click", () => playAudio(data.arabicAudioTracks, data.arabicAudioUrl, data.translation, "ar"));
  resultBox.querySelector(".copy").addEventListener("click", async (event) => {
    await navigator.clipboard.writeText(data.translation);
    event.currentTarget.textContent = "Copied";
  });
}

function playAudio(tracks, legacyUrl, text, language) {
  const runId = ++audioRunId;
  if (activeAudio) activeAudio.pause();
  speechSynthesis.cancel();
  const queue = Array.isArray(tracks) && tracks.length ? tracks : [{ text, url: legacyUrl || "" }];
  let index = 0;
  const playNext = () => {
    if (runId !== audioRunId || index >= queue.length) return;
    const track = queue[index++];
    if (!track.url) {
      speak(track.text, language, playNext, runId);
      return;
    }
    activeAudio = new Audio(track.url);
    activeAudio.preload = "auto";
    let settled = false;
    const finishTrack = () => {
      if (settled) return;
      settled = true;
      playNext();
    };
    const fallbackTrack = () => {
      if (settled) return;
      settled = true;
      speak(track.text, language, playNext, runId);
    };
    activeAudio.addEventListener("ended", finishTrack, { once: true });
    activeAudio.addEventListener("error", fallbackTrack, { once: true });
    activeAudio.play().catch(fallbackTrack);
  };
  playNext();
}

function speak(text, language, onEnd, runId = audioRunId) {
  const utterance = new SpeechSynthesisUtterance(text);
  utterance.lang = language;
  utterance.rate = language.startsWith("de") ? 0.88 : 0.82;
  utterance.onend = () => {
    if (runId === audioRunId) onEnd?.();
  };
  speechSynthesis.speak(utterance);
}

function escapeHtml(value) {
  return String(value || "").replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character]));
}

async function openPdfViewer() {
  let source = "";
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
    if (/^(https?:|file:)/i.test(tab?.url || "")) source = tab.url;
  } catch (_) {}
  const viewerUrl = chrome.runtime.getURL("viewer/viewer.html") + (source ? `?file=${encodeURIComponent(source)}` : "");
  await chrome.tabs.create({ url: viewerUrl });
  window.close();
}
