const defaults = { showSelectionIcon: true, showExamples: true, fallbackTranslation: true, maxExamples: 3 };
const ids = Object.keys(defaults);
const saved = document.querySelector("#saved");

chrome.storage.sync.get(defaults).then((settings) => {
  for (const id of ids) {
    const element = document.querySelector(`#${id}`);
    if (element.type === "checkbox") element.checked = settings[id];
    else element.value = String(settings[id]);
  }
});

document.querySelector("section").addEventListener("change", async () => {
  const settings = {};
  for (const id of ids) {
    const element = document.querySelector(`#${id}`);
    settings[id] = element.type === "checkbox" ? element.checked : Number(element.value);
  }
  await chrome.storage.sync.set(settings);
  saved.textContent = "Settings saved";
  setTimeout(() => { saved.textContent = ""; }, 1400);
});
