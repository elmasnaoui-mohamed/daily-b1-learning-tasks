(function (root) {
  "use strict";

  const decodeEntities = (value) => String(value || "")
    .replace(/&nbsp;/gi, " ")
    .replace(/&amp;/gi, "&")
    .replace(/&quot;/gi, '"')
    .replace(/&#39;|&apos;/gi, "'")
    .replace(/&lt;/gi, "<")
    .replace(/&gt;/gi, ">")
    .replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n)))
    .replace(/&#x([\da-f]+);/gi, (_, n) => String.fromCodePoint(parseInt(n, 16)));

  const clean = (html) => decodeEntities(
    String(html || "")
      .replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, " ")
      .replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, " ")
      .replace(/<[^>]+>/g, " ")
  ).replace(/\s+/g, " ").trim();

  function extractColumn(block, language) {
    const matcher = new RegExp(
      `<div[^>]*class="[^"]*item-col[^"]*"[^>]*lang="${language}"[^>]*>([\\s\\S]*?)(?=<div[^>]*class="[^"]*item-col|<\\/div>\\s*<\\/div>\\s*<\\/div>)`,
      "i"
    );
    return clean((block.match(matcher) || [])[1]);
  }

  function parseSearchPage(html, query) {
    const entries = [];
    const seen = new Set();
    const blocks = String(html || "").match(/<li[^>]*class="[^"]*res-item[^"]*"[^>]*>[\s\S]*?<\/li>/gi) || [];

    for (const block of blocks) {
      const german = extractColumn(block, "de");
      const arabic = extractColumn(block, "ar");
      const id = ((block.match(/id="_(\d+)_"/i) || [])[1]) || "";
      if (!german || !arabic) continue;
      const key = `${german}\u0000${arabic}`;
      if (seen.has(key)) continue;
      seen.add(key);
      entries.push({ german, arabic, id });
      if (entries.length === 8) break;
    }

    const needle = String(query).toLocaleLowerCase("de-DE").replace(/[.!?]+$/g, "").trim();
    const exact = entries.find((entry) =>
      entry.german.toLocaleLowerCase("de-DE").includes(needle)
    ) || entries[0];
    const isExact = Boolean(exact && exact.german.toLocaleLowerCase("de-DE").includes(needle));
    return { entries, exact, isExact };
  }

  function parseExamplesPage(html) {
    const examples = [];
    const section = (String(html || "").match(/<ul[^>]*id="details-Examples"[^>]*>([\s\S]*?)<\/ul>/i) || [])[1] || "";
    const rows = section.match(/<li[^>]*>[\s\S]*?<\/li>/gi) || [];
    for (const row of rows) {
      const german = clean((row.match(/<div[^>]*lang="de"[^>]*>([\s\S]*?)<\/div>/i) || [])[1]);
      const arabic = clean((row.match(/<div[^>]*lang="ar"[^>]*>([\s\S]*?)<\/div>/i) || [])[1]);
      if (german && arabic) examples.push({ german, arabic });
      if (examples.length === 4) break;
    }
    return examples;
  }

  root.ArabdictParser = { clean, parseSearchPage, parseExamplesPage };
})(typeof self !== "undefined" ? self : globalThis);
