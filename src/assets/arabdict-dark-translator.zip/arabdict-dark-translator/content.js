(() => {
  "use strict";
  if (window.top !== window) return;

  const host = document.createElement("div");
  host.id = "arabdict-dark-translator-root";
  host.style.cssText = "all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none";
  document.documentElement.appendChild(host);
  const root = host.attachShadow({ mode: "closed" });

  root.innerHTML = `
    <style>
      *{box-sizing:border-box}button,a{font:inherit}.hidden{display:none!important}
      .trigger{position:fixed;width:42px;height:42px;padding:0;border:1px solid #7568ff;border-radius:13px;background:#10111d;color:#fff;box-shadow:0 10px 30px #0008;display:grid;place-items:center;overflow:hidden;cursor:pointer;pointer-events:auto;transition:.15s transform,.15s border-color}
      .trigger:hover{transform:translateY(-2px);border-color:#a197ff}.trigger img{width:100%;height:100%;object-fit:cover}
      .card{position:fixed;width:min(390px,calc(100vw - 40px));max-height:min(620px,calc(100dvh - 48px));overflow:hidden;display:flex;flex-direction:column;pointer-events:auto;direction:ltr;color:#f5f4ff;background:linear-gradient(145deg,#151625,#0c0d16);border:1px solid #30324b;border-radius:20px;box-shadow:0 24px 70px #000a;font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif}
      .top{flex:0 0 auto;z-index:2;display:flex;align-items:center;gap:11px;padding:13px 14px;background:#151625ee;backdrop-filter:blur(14px);border-bottom:1px solid #292b42}.brand{width:38px;height:38px;border-radius:12px;display:block;object-fit:cover;box-shadow:0 5px 16px #0007}.title{flex:1;font-size:12px;font-weight:700;letter-spacing:.02em}.lang{font-size:11px;color:#aaa8bd;font-weight:750;letter-spacing:.04em}.iconbtn{width:30px;height:30px;border:0;border-radius:9px;background:transparent;color:#aaa8bd;cursor:pointer}.iconbtn:hover{background:#292b42;color:#fff}
      .scrollwrap{min-height:0;overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain;scrollbar-width:thin;scrollbar-color:#6658d8 transparent}.scrollwrap::-webkit-scrollbar{width:8px}.scrollwrap::-webkit-scrollbar-track{background:transparent;margin:10px 0}.scrollwrap::-webkit-scrollbar-thumb{background:linear-gradient(#7b6cf4,#5548ba);border:2px solid #11121d;border-radius:999px}.scrollwrap::-webkit-scrollbar-thumb:hover{background:linear-gradient(#9387ff,#6c5ce7)}
      .body{padding:16px}.label{margin-bottom:6px;color:#8e8ca3;font-size:9px;font-weight:800;letter-spacing:.12em;text-transform:uppercase}.queryrow{display:flex;align-items:center;gap:8px}.query{flex:1;font-size:17px;font-weight:650;line-height:1.35;color:#e7e6ef;word-break:break-word}.wordaudio{flex:0 0 auto;width:34px;height:34px;border:1px solid #34364d;border-radius:10px;background:#1a1b2b;color:#d8d5e5;cursor:pointer}.wordaudio:hover{border-color:#6c5ce7;color:#fff}.translation{margin-top:12px;padding:12px 14px;border:1px solid #393558;border-radius:15px;background:#201e35;color:#fff;font-family:"Noto Naskh Arabic","Segoe UI",sans-serif;font-size:19px;line-height:1.48;text-align:right;direction:rtl}
      .actions{display:flex;gap:8px;margin-top:9px}.action{border:1px solid #34364d;border-radius:10px;background:#1a1b2b;color:#cbc9d8;padding:7px 10px;cursor:pointer;font-size:11px}.action:hover{border-color:#6c5ce7;color:#fff}.action.primary{margin-left:auto;background:#6c5ce7;border-color:#6c5ce7;color:#fff;text-decoration:none}
      .section{margin-top:16px}.entries{display:grid;gap:7px}.entry{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:10px;padding:8px 10px;border-radius:11px;background:#191a29;font-size:11px}.entry .ar{text-align:right;direction:rtl;font-family:"Noto Naskh Arabic","Segoe UI",sans-serif;font-size:14px;color:#d9d4ff}.entry .de{align-self:center;color:#bcbaca;overflow:hidden;text-overflow:ellipsis}
      .examples{display:grid;gap:8px}.example{padding:10px;border:1px solid #292b42;border-radius:12px;background:#11121d}.example .de{font-size:11px;line-height:1.45;color:#d1cfda}.example .ar{margin-top:6px;padding-top:6px;border-top:1px solid #24263a;font-size:15px;line-height:1.5;text-align:right;direction:rtl;color:#f1efff}
      .status{min-height:190px;display:grid;place-items:center;text-align:center;color:#aaa8bd;font-size:12px}.status>div{display:grid;justify-items:center}.spinner{width:30px;height:30px;margin:0 auto;border:3px solid #34364d;border-top-color:#8174ff;border-radius:50%;animation:spin .7s linear infinite}@keyframes spin{to{transform:rotate(360deg)}}
      .error{color:#ff9b9b}.foot{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:2px 16px 15px;color:#747287;font-size:10px}.byline{color:#9e9bad;font-size:11px;font-weight:700;letter-spacing:.03em;white-space:nowrap}.toast{position:fixed;right:16px;bottom:16px;padding:10px 14px;border-radius:10px;background:#2d2f46;color:white;box-shadow:0 10px 30px #0008;font:12px system-ui;pointer-events:auto}
      @media(max-width:520px){.card{left:20px!important;right:20px!important;width:auto;max-height:calc(100dvh - 40px)}.translation{font-size:18px}}
    </style>
    <button class="trigger hidden" type="button" aria-label="Translate selected text"><img alt="" src="${chrome.runtime.getURL("assets/logo.png")}"></button>
    <section class="card hidden" role="dialog" aria-label="German to Arabic translation"></section>
    <div class="toast hidden"></div>`;

  const trigger = root.querySelector(".trigger");
  const card = root.querySelector(".card");
  const toast = root.querySelector(".toast");
  let selectedText = "";
  let anchor = { x: 20, y: 20 };
  let enabled = true;
  let activeAudio = null;
  let audioRunId = 0;

  chrome.storage.sync.get({ showSelectionIcon: true }).then((settings) => { enabled = settings.showSelectionIcon; });
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area === "sync" && changes.showSelectionIcon) enabled = changes.showSelectionIcon.newValue;
  });

  function currentSelection() {
    const selection = window.getSelection();
    const text = selection?.toString().replace(/\s+/g, " ").trim() || "";
    if (!selection || selection.rangeCount === 0 || !text) return null;
    const rect = selection.getRangeAt(0).getBoundingClientRect();
    return { text: text.slice(0, 1500), rect };
  }

  function place(element, x, y, width, height) {
    const margin = 12;
    const left = Math.min(Math.max(margin, x), window.innerWidth - width - margin);
    const top = Math.min(Math.max(margin, y), window.innerHeight - height - margin);
    element.style.left = `${left}px`;
    element.style.top = `${top}px`;
  }

  function positionCard(point) {
    const margin = 24;
    requestAnimationFrame(() => {
      const rect = card.getBoundingClientRect();
      const left = Math.min(Math.max(margin, point.x), window.innerWidth - rect.width - margin);
      const top = Math.min(Math.max(margin, point.y), window.innerHeight - rect.height - margin);
      card.style.left = `${Math.max(margin, left)}px`;
      card.style.top = `${Math.max(margin, top)}px`;
    });
  }

  function revealTrigger(pointer) {
    setTimeout(() => {
      if (!card.classList.contains("hidden")) return;
      const result = currentSelection();
      if (!result || !enabled || result.text.length > 1500) {
        trigger.classList.add("hidden");
        return;
      }
      selectedText = result.text;
      anchor = pointer && Number.isFinite(pointer.x) && Number.isFinite(pointer.y)
        ? { x: pointer.x + 10, y: pointer.y + 10 }
        : { x: result.rect.right + 8, y: result.rect.bottom + 8 };
      place(trigger, anchor.x, anchor.y, 42, 42);
      trigger.classList.remove("hidden");
    }, 10);
  }

  document.addEventListener("mouseup", (event) => {
    revealTrigger({ x: event.clientX, y: event.clientY });
  }, true);
  document.addEventListener("keyup", (event) => {
    if (event.key.startsWith("Arrow") || event.key === "Shift") revealTrigger();
  }, true);
  window.addEventListener("scroll", () => trigger.classList.add("hidden"), true);
  document.addEventListener("pointerdown", (event) => {
    if (!card.classList.contains("hidden") && event.target !== host) closeCard();
  }, true);

  trigger.addEventListener("click", (event) => {
    event.preventDefault();
    event.stopPropagation();
    openLookup(selectedText, anchor);
  });

  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "arabdict-context-lookup") {
      openLookup(message.text, { x: window.innerWidth / 2 - 190, y: 80 });
    }
  });

  async function openLookup(text, point) {
    selectedText = String(text || "").trim();
    trigger.classList.add("hidden");
    card.innerHTML = header() + `<div class="scrollwrap"><div class="status"><div><div class="spinner"></div><div style="margin-top:12px">Looking up Arabdict…</div></div></div></div>`;
    card.classList.remove("hidden");
    positionCard(point);
    bindHeader();
    try {
      const result = await chrome.runtime.sendMessage({ type: "arabdict-lookup", text: selectedText });
      if (!result?.ok) throw new Error(result?.error || "Translation failed.");
      render(result, point);
    } catch (error) {
      card.innerHTML = header() + `<div class="scrollwrap"><div class="status error"><div><strong>Could not translate</strong><br><span>${escapeHtml(error.message)}</span></div></div></div>`;
      bindHeader();
      positionCard(point);
    }
  }

  function header() {
    return `<div class="top"><img class="brand" alt="Deutsch mit Rinkute" src="${chrome.runtime.getURL("assets/logo.png")}"><div class="title"><span class="lang">DE → AR</span></div><button class="iconbtn options" title="Options" aria-label="Options">⚙</button><button class="iconbtn close" title="Close" aria-label="Close">✕</button></div>`;
  }

  function bindHeader() {
    card.querySelector(".close")?.addEventListener("click", closeCard);
    card.querySelector(".options")?.addEventListener("click", () => chrome.runtime.sendMessage({ type: "arabdict-options" }));
  }

  function closeCard() {
    card.classList.add("hidden");
    audioRunId += 1;
    if (activeAudio) {
      activeAudio.pause();
      activeAudio = null;
    }
    speechSynthesis.cancel();
  }

  function render(data, point) {
    const entries = data.entries.length > 1 ? `<div class="section"><div class="label">More meanings</div><div class="entries">${data.entries.slice(0, 5).map((item) => `<div class="entry"><div class="de">${escapeHtml(item.german)}</div><div class="ar" lang="ar">${escapeHtml(item.arabic)}</div></div>`).join("")}</div></div>` : "";
    const examples = data.examples.length ? `<div class="section"><div class="label">Examples in context</div><div class="examples">${data.examples.map((item) => `<div class="example"><div class="de">${escapeHtml(item.german)}</div><div class="ar" lang="ar">${escapeHtml(item.arabic)}</div></div>`).join("")}</div></div>` : "";
    card.innerHTML = header() + `<div class="scrollwrap"><div class="body"><div class="label">German</div><div class="queryrow"><div class="query">${escapeHtml(data.query)}</div><button class="wordaudio speak-de" type="button" title="Play Arabdict German pronunciation" aria-label="Play Arabdict German pronunciation">🔊</button></div><div class="translation" lang="ar">${escapeHtml(data.translation)}</div><div class="actions"><button class="action speak-ar" type="button">🔊 Arabic</button><button class="action copy" type="button">Copy</button><a class="action primary" href="${escapeHtml(data.sourceUrl)}" target="_blank" rel="noopener">Open Arabdict ↗</a></div>${entries}${examples}</div><div class="foot"><span>Results: ${escapeHtml(data.source)}</span><span class="byline">By Rinkute</span></div></div>`;
    bindHeader();
    card.querySelector(".copy").addEventListener("click", async () => {
      await navigator.clipboard.writeText(data.translation);
      showToast("Arabic translation copied");
    });
    card.querySelector(".speak-de").addEventListener("click", () => playPronunciation(data.germanAudioTracks, data.germanAudioUrl, data.query, "de-DE"));
    card.querySelector(".speak-ar").addEventListener("click", () => playPronunciation(data.arabicAudioTracks, data.arabicAudioUrl, data.translation, "ar"));
    positionCard(point);
  }

  function playPronunciation(tracks, legacyUrl, text, language) {
    const runId = ++audioRunId;
    if (activeAudio) {
      activeAudio.pause();
      activeAudio = null;
    }
    speechSynthesis.cancel();
    const queue = Array.isArray(tracks) && tracks.length
      ? tracks
      : [{ text, url: legacyUrl || "" }];
    let index = 0;
    const playNext = () => {
      if (runId !== audioRunId || index >= queue.length) return;
      const track = queue[index++];
      if (!track.url) {
        speak(track.text, language, playNext, runId);
        return;
      }
      activeAudio = new Audio(track.url);
      activeAudio.preload = "auto";
      let settled = false;
      const finishTrack = () => {
        if (settled) return;
        settled = true;
        playNext();
      };
      const fallbackTrack = () => {
        if (settled) return;
        settled = true;
        speak(track.text, language, playNext, runId);
      };
      activeAudio.addEventListener("ended", finishTrack, { once: true });
      activeAudio.addEventListener("error", fallbackTrack, { once: true });
      activeAudio.play().catch(fallbackTrack);
    };
    playNext();
  }

  function speak(text, language, onEnd, runId = audioRunId) {
    speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = language;
    const prefix = language.toLowerCase().split("-")[0];
    const voice = speechSynthesis.getVoices().find((candidate) => candidate.lang.toLowerCase().startsWith(prefix));
    if (voice) utterance.voice = voice;
    utterance.rate = language.startsWith("de") ? 0.88 : 0.82;
    utterance.onend = () => {
      if (runId === audioRunId) onEnd?.();
    };
    speechSynthesis.speak(utterance);
  }

  function showToast(text) {
    toast.textContent = text;
    toast.classList.remove("hidden");
    setTimeout(() => toast.classList.add("hidden"), 1700);
  }

  function escapeHtml(value) {
    return String(value || "").replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character]));
  }
})();
